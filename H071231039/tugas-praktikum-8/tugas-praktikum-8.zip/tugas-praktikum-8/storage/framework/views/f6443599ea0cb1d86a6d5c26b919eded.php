<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-6 text-center text-md-start">
                <p class="mb-0">&copy; 2024 Pupuk Kaltim Portfolio Manager Project TI. All rights reserved.</p>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <div class="social-icons">
                    <a href="https://github.com/Rezka08" target="_blank"><i class="fab fa-github"></i></a>
                    <a href="https://www.linkedin.com/in/rezka-wildan-22a321290" target="_blank"><i class="fab fa-linkedin"></i></a>
                    <a href="https://x.com/12ezka" target="_blank"><i class="fab fa-twitter"></i></a>
                    <a href="https://www.instagram.com/rzkaaa.08" target="_blank"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\Users\ASUS\Documents\TUGAS KULIAH SEMESTER 3\Tugas Praktikum Web\TP8\tugas-praktikum-8\resources\views/partials/footer.blade.php ENDPATH**/ ?>