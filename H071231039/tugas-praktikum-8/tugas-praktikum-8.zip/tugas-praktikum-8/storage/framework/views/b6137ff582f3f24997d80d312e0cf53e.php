<?php if(request()->routeIs('home')): ?>
<section class="hero-section text-center">
    <div class="container">
        <h1 class="display-4">Hello im Rezka Wildan</h1>
        <h1 class="display-4">Welcome to My Portfolio</h1>
        <p class="lead">Web Developer | Designer | Creative Thinker</p>
        <div class="mt-4">
            <a href="<?php echo e(route('about')); ?>" class="btn btn-light btn-lg me-3">Learn More</a>
            <a href="<?php echo e(route('contact')); ?>" class="btn btn-outline-light btn-lg">Contact Me</a>
        </div>
    </div>
</section>
<?php endif; ?><?php /**PATH C:\Users\ASUS\Documents\TUGAS KULIAH SEMESTER 3\Tugas Praktikum Web\TP8\tugas-praktikum-8\resources\views/partials/hero.blade.php ENDPATH**/ ?>