@extends('layouts.master')

@section('title', 'About')

@section('content')
<div class="row">
    <div class="col-md-8 offset-md-2">
        <div class="card shadow-sm">
            <div class="card-body">
                <h2 class="text-center mb-4"><b>About Me</b></h2>
                <div class="row">
                    <div class="col-md-4 text-center mb-4">
                        <img src="{{ asset('img/fotodirga.jpg') }}" alt="Profile" class="rounded-circle img-fluid mb-3">
                        <h4>Muhammad Dirga Dian Nugraha</h4>
                        <p class="text-muted">Information System Student</p>
                    </div>
                    <div class="col-md-8">
                        <h5>Professional Background</h5>
                        <p>
                        I am a Software Developer, specializing in creating 
                        efficient software solutions that support and streamline industrial 
                        operations. My role involves coding, testing, and optimizing systems 
                        to ensure they meet organizational needs. With a strong focus on best 
                        practices and scalable code, I contribute to the company’s digital 
                        transformation and continually seek to expand my skills to drive further value.
                        </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
