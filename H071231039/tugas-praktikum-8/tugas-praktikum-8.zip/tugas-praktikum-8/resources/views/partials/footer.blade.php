<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-6 text-center text-md-start">
                <p class="mb-0">&copy; 2024 Portfolio Manager Project TI. All rights reserved.</p>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <div class="social-icons">
                    <a href="https://github.com/SuciZaitunNurkamal" target="_blank"><i class="fab fa-github"></i></a>
                    <a href="https://www.linkedin.com/in/suci-zaitun-nur-kamal-786043233/" target="_blank"><i class="fab fa-linkedin"></i></a>
                    <a href="https://www.instagram.com/sucizaitunn" target="_blank"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </div>
    </div>
</footer>