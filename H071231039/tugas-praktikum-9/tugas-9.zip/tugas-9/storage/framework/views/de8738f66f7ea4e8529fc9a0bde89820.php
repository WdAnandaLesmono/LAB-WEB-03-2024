

<?php $__env->startSection('content'); ?>
    <div class="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50">
        <div
            class="bg-white shadow-lg rounded-2xl w-full max-w-lg mx-4 p-1 [--shadow:rgba(60,64,67,0.3)_0_1px_2px_0,rgba(60,64,67,0.15)_0_2px_6px_2px] [box-shadow:var(--shadow)]">
            <div class="px-4 py-3 sm:px-6">
                <div class="flex justify-center">
                    <h2 class="text-2xl font-bold text-[#A78295] text-center mb-0">Add Inventory Log</h2>
                </div>
                <form action="<?php echo e(route('inventory-logs.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-1">
                        <label for="product_id" class="block text-lg font-bold text-[#000]">Product</label>
                        <select
                            class="block w-full pl-3 pr-10 py-1 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md appearance-none"
                            id="product_id" name="product_id" required>
                            <option value="">Select Product</option>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($product->id); ?>"
                                    <?php echo e(old('product_id') == $product->id ? 'selected' : ''); ?>>
                                    <?php echo e($product->name); ?> (Current Stock: <?php echo e($product->stock); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-sm text-red-600"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-1">
                        <label for="type" class="block text-lg font-bold text-[#000]">Type</label>
                        <select
                            class="block w-full pl-3 pr-10 py-1 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md appearance-none"
                            id="type" name="type" required>
                            <option value="restock" <?php echo e(old('type') == 'restock' ? 'selected' : ''); ?>>Restock</option>
                            <option value="sold" <?php echo e(old('type') == 'sold' ? 'selected' : ''); ?>>Sold</option>
                        </select>
                        <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-sm text-red-600"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-1">
                        <label for="quantity" class="block text-lg font-bold text-[#000]">Quantity</label>
                        <input type="number"
                            class="block w-full px-3 py-1 text-gray-900 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                            id="quantity" name="quantity" value="<?php echo e(old('quantity')); ?>" min="1" required>
                        <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-sm text-red-600"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="flex justify-between mt-3">
                        <a href="<?php echo e(route('inventory-logs.index')); ?>"
                            class="py-2 px-6 bg-[#d32323] rounded-l-lg text-white text-center flex-1 mx-1">Cancel</a>
                        <button type="submit"
                            class="py-2 px-6 bg-[#A78295] rounded-r-lg text-white text-center flex-1 mx-1">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Zainab\Berkas Zainab\Semester 3\Pemrograman Web B\Praktikum\P9\tugas-pertemuan-09\resources\views/inventory_logs/create.blade.php ENDPATH**/ ?>