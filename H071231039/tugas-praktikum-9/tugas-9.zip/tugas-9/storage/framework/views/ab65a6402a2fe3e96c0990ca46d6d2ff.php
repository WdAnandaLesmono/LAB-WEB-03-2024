<footer class="fixed bottom-0 left-0 z-20 w-full p-4 bg-gray-900 text-[#8da9de] border-t border-gray-600">
    <div class="container mx-auto">
        <hr class="border-t border-[#8da9de]">
        <div class="flex justify-between items-center mt-4">
            <h1 class="text-sm" style="color: #8da9de; font-size: 14px;">© 2024 | SmartStore</h1>
            <ul class="flex space-x-4 text-sm font-medium text-[#8da9de]">
                <li><a href="#" class="hover:underline">About</a></li>
                <li><a href="#" class="hover:underline">Privacy Policy</a></li>
                <li><a href="#" class="hover:underline">Licensing</a></li>
                <li><a href="#" class="hover:underline">Contact</a></li>
            </ul>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\farar\OneDrive\Documents\Semester 3 - SISTEM INFORMASI\Pemprograman Web\Web Pemrograman\tugas-pertemuan-09\resources\views/Partials/footer.blade.php ENDPATH**/ ?>